/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
#include "main.h"

#include "ssd1306.h"
#include "config.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

uint8_t interrupt_trigger;

int main(void)
{
  /* Reset of all peripherals. */
  HAL_Init();

  /* Configure the system clock */
  SystemClock_Config();

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C1_Init();
  MX_USART3_UART_Init();
  MX_USB_OTG_FS_PCD_Init();  
  ssd1306_Init();
	
  char message[100];
	print_msg("Test");

  // Your start up code here
	
  while (1){
		/*
		HAL_GPIO_TogglePin(LD2_GPIO_Port, LD2_Pin);
    HAL_Delay(500);
    print_msg("\b\b\b\btick"); */
		//if (HAL_I2C_Mem_Read(&hi2c1, SSD1306_I2C_ADDR, address, I2C_MEMADD_SIZE_16BIT, &data, 1, 100) != HAL_OK) {
		//	Error_Handler();
		//}
		
		ssd1306_DrawPixel(5, 5, White);
		ssd1306_UpdateScreen();
		HAL_Delay(1000);
		print_msg("running");
		
		/*
    HAL_GPIO_TogglePin(LD2_GPIO_Port, LD2_Pin);
    HAL_Delay(500);
    print_msg("\b\b\b\btock"); */
		/*
		ssd1306_Fill(Black);
		ssd1306_UpdateScreen();
		HAL_Delay(1000);*/

  }
}
